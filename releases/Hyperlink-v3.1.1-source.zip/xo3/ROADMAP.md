# Rencana perbaikan Hyperlink

## P0 — Wajib sebelum dipakai uang sungguhan
1. Uji di perangkat: build APK di GitHub Actions, jalankan `npm test`, lalu cek tarik-refresh, pair picker, chart, intro di HP nyata (belum pernah dijalankan di perangkat).
2. Uji tiap exchange di testnet/akun kecil: submit order, TP/SL, tutup posisi, pembacaan saldo (Bybit, Bitget, OKX, Binance).
3. Pengaman order Live: batas maksimum rugi harian, batas jumlah posisi, kill-switch "Hentikan semua", konfirmasi ulang saat leverage tinggi.
4. Penanganan error jaringan/rate-limit yang seragam (retry + backoff) untuk exchange, CoinGecko, Gemini.

## P1 — Fitur yang masih kurang
- Order Live: daftar order terbuka + batalkan, edit leverage/mode margin posisi, multi-TP dan trailing stop, riwayat transaksi/PnL.
- Harga real-time lewat WebSocket (sekarang polling ±60 dtk) + order book dan trade terbaru.
- Chart: volume, zoom/geser, indikator tambahan (RSI, EMA), interval lebih banyak (3m, 30m, 2j, 12j).
- Alert harga dan notifikasi lokal saat signal masuk / posisi kena TP-SL (sekarang hanya notifikasi service).
- Demo: statistik per sumber signal, ekspor/impor data demo, grafik ekuitas, funding fee simulasi.
- Keamanan: kunci aplikasi (biometrik/PIN), sembunyikan saldo global, izin API read-only vs trade.
- Pengaturan API CoinGecko (key demo) agar tidak mudah kena batas request.
- Ikon launcher sesuai logo baru; mode landscape/tablet; bahasa Inggris.

## P2 — Tampilan ala exchange
- Selesai di v2.3: kartu aset (sembunyikan saldo), kartu posisi (PnL/ROE, grid harga, TP/SL strip, tombol chart), nav bar datar dengan indikator atas.
- Berikutnya: tab Pasar dengan baris watchlist yang sama dengan pair picker, sheet order gaya exchange (Long/Short besar, slider margin %), skeleton loading, empty state berilustrasi.

## Teknis
- Tes UI (render App), tes adapter dengan fixture respons asli, CI yang menjalankan `tsc`, `jest`, dan `assembleRelease`.
- Pecah `controller.ts` (600+ baris) menjadi hook per domain.

---
Status v2.4: lihat bagian "v2.4" di README.
