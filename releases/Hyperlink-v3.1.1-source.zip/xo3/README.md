# Hyperlink

Aplikasi React Native Android: signal Telegram (TDLib) → analisis Gemini → pengecekan risiko → order ke exchange pilihan Anda, plus akun Demo paper trading lokal dengan sumber harga CoinGecko atau market exchange terpilih.

## v3.1.1 — Fokus UI & backdrop blur
- Navbar lebih transparan agar backdrop blur tampak jelas; transisi tetap ringan dan blur tidak dianimasikan per frame.
- Chart call terbaru pada Beranda Live dan Demo dimulai dalam keadaan minim, dengan tombol untuk membuka atau meminimalkan secara manual.
- Popover, menu, bottom sheet, dan konfirmasi aplikasi meredupkan serta memburamkan konten di belakangnya; aksi berisiko tetap memerlukan konfirmasi eksplisit.
- Rilis Android: **arm64-v8a only**, minSdk **31**, targetSdk **36**, versionName **3.1.1**, versionCode **35**. Package ID `com.tradepilotnative` serta perilaku trading dan pengaman dipertahankan.

## v3.1.0 — DeafDeep & glass UI
- Template suara WND11 diganti **DeafDeep**, menjadi default baru; lima WAV yang diberikan dipetakan ke tap, pilihan/slider, buka PIN, konfirmasi order, error, dan notifikasi dalam aplikasi. Audio UI tetap memakai volume media.
- Navbar memakai backdrop blur native adaptif pada konten halaman dengan tint transparan sebagai fallback; intensitas blur tetap konstan agar tidak menambah update per frame.
- Pilihan preset satu-nilai yang sudah berupa chip di Settings kini dibuka melalui popover kecil beranimasi tepat dari chip; pilihan banyak channel Telegram tetap inline.
- Heading atas **Hyperlink** memakai font sistem (San Francisco di iOS, sans-serif sistem Android) dengan gaya bold italic.
- Rilis Android: **arm64-v8a only**, minSdk **31**, targetSdk **36**, versionName **3.1.0**, versionCode **34**. Package ID `com.tradepilotnative` dan pemisahan Live/Demo tetap dipertahankan.

## v2.8
- Order Manual: preset chips removed; TP/SL (ROI) and limit-price offset are now sliders; Dial and sliders update the form at most every ~90 ms (no more frame drops), quantity is derived instead of re-set by an effect.
- PIN: larger, symmetric rounded tiles, springier orbit, faster spin with wind-up and bounce-back settle, key squeeze, double ring + 20 particle burst.
- Exchange-style alerts (toast + system notification in background): Open Entry, Take Profit / Stop Loss hit, liquidation risk at >=75% and "hampir margin call" at >=90% (Demo and Live; Live TP/SL is inferred from position diffs between syncs).

## Exchange yang didukung (pilih di Pengaturan)

| Exchange | API | Passphrase | Testnet/Demo |
|---|---|---|---|
| Bitget | UTA v3, USDT-FUTURES | ya | tidak ada (gunakan mode Demo aplikasi) |
| Bybit | V5 linear | tidak | ya (testnet) |
| OKX | v5 SWAP | ya | ya (demo trading) |
| Binance | USDⓈ-M Futures | tidak | ya (futures testnet) |

Setiap exchange menyimpan key sendiri di Android Keystore (react-native-keychain). Data credential versi lama dimigrasikan otomatis; kunci CoinMarketCap lama tidak lagi dipakai.

## Alur dan pengaman

- Signal divalidasi (arah SL/TP, leverage 1–100, SL×leverage < 90%).
- Call Telegram dengan zona entry dan beberapa target TP menyimpan semua level. Mode Demo menunggu harga masuk zona entry dan menutup posisi bertahap di setiap TP.
- Rencana order live memakai aturan instrumen exchange (tick, step qty, min notional) dan hanya dibuat ketika harga berada dalam zona entry call; signal basi atau SL/TP sudah terlewati diblokir.
- Order Live manual tersedia di tab Pasar dan selalu menampilkan payload final serta konfirmasi pengguna; Stop Loss native wajib. Auto-entry Live adalah pilihan terpisah, mati secara default, dan hanya berjalan jika mode Live, automation Telegram, dan opt-in Live semuanya aktif.
- Order live pada adapter exchange saat ini memasang satu TP native (TP1); target tambahan tetap ditampilkan pada call untuk pengelolaan bertahap. Mode Demo menjalankan seluruh target secara otomatis.
- Binance: bila SL gagal terpasang setelah entry, posisi ditutup otomatis.

## Fitur v2.1

- **Kelola posisi di exchange** (tab Posisi): baca saldo & posisi live, ubah/hapus SL dan TP, tutup sebagian (25/50/75/100%) atau semua posisi, lengkap dengan liquidation dan ROE. Berlaku untuk Bybit, Bitget, OKX, Binance. Auto-refresh 20 detik.
- **Margin untuk semua call**: slider 1–100% dari saldo tersedia + Isolated/Cross, bisa tetap atau mengikuti **saran AI per call**. Tiap call bisa diatur manual di kartunya.
- **Saran AI margin**: baseline lokal (jarak SL × leverage, R:R, confidence, leverage) lalu Gemini memberi pendapat; hasil AI dibatasi maksimal 1.5× baseline agar tidak mendorong risiko berlebihan.
- **Akun Demo independen dari order Live**: pilih CoinGecko atau ticker publik exchange yang sedang dipilih untuk harga simulasi. Demo tetap lokal dan tidak mengirim order exchange. Mendukung market/limit, LONG/SHORT, leverage, Isolated/Cross, TP/SL, partial close, likuidasi simulasi, order tertunda, histori, dan statistik.
- **Chart Live dan Demo**: candlestick OHLC, sumbu harga, garis quote, dan chart call terbaru; aset dapat dipilih melalui popup pencarian berkategori atau pair manual. Sumber chart dapat mengikuti CoinGecko atau exchange terpilih.
- **Pilihan chart**: popup timeframe berikon dengan kategori cepat, intraday, dan tren (1m–1w) untuk exchange; CoinGecko memakai rentang OHLC yang disediakan API. Interval dipetakan ke endpoint candle tiap exchange.
- **Replay signal** memakai candle OHLC CoinGecko yang tersedia. Granularitas dan panjang histori mengikuti rentang candle yang disediakan provider.
- **Tab Pasar**: pilih data kapitalisasi, dominasi BTC/ETH, ranking, top naik/turun, volume, trending, dan detail dari CoinGecko atau ticker futures publik exchange terpilih. Chart pada detail memakai provider yang sama.
- **Tampilan**: tema Monochrome, Material You, Midnight Exchange, Emerald Wallet, Aurora Slate, dan Copper Studio; semuanya mendukung mode warna Sistem, Terang, atau Gelap.
- **UI dirapikan**: menu aksi signal, filter pasar dan signal, serta kontrol sinkron/tutup posisi ditempatkan lebih mudah dijangkau; pilihan membungkus otomatis ke beberapa baris.
- **Mode akun cepat**: tersedia di semua tab saat scroll berada di atas; tarik lalu lepas untuk refresh halaman, atau tarik lebih jauh dan tahan 3,2 detik untuk beralih Live/Demo. Indikator progres bulat lebih besar menampilkan tindakan aktif.
- **Intro pembuka**: splash logo monochrome minimal 3 detik; onboarding pertama ikut menutup otomatis sesudahnya atau lebih cepat jika tombol Mulai ditekan.
- **Notifikasi ringkas**: snackbar memiliki ikon status dan teks maksimal dua baris; notifikasi background hanya menampilkan status pemantauan yang penting.
- **Riwayat signal di bagian teratas** tab Signal. Kartu call menampilkan rentang entry dan daftar TP lengkap.
- **Posisi Demo terpisah**: tab Posisi menampilkan ekuitas, order tertunda, TP bertingkat, pengaturan SL/TP, serta penutupan parsial demo tanpa mencampur posisi exchange Live.

## Fitur

Mode Live/Demo, chart Demo dari CoinGecko atau exchange terpilih, daftar & tes model Gemini, scan riwayat channel Telegram, layanan latar belakang, enam palet tema dan mode warna terang/gelap/sistem.

## Build

```bash
npm ci
bash scripts/prepare-tdlib.sh
cd android && ./gradlew assembleRelease
```

GitHub: push ke repo, jalankan workflow **Build Hyperlink APK** (Actions → Run workflow). APK ada di Artifacts. Tag `v*` melampirkan APK ke Release. Untuk tanda tangan sendiri isi secrets `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`; tanpa itu APK ditandatangani debug key. Source 3.1.1 dikonfigurasi untuk satu target **arm64-v8a** dengan versionCode **35**.

## Catatan

Coba dulu di testnet/demo sebelum memakai dana nyata. Perilaku API diverifikasi terhadap dokumentasi dan tes mock, belum terhadap akun live.


## Catatan v2.2
- Beranda: tarik cepat lalu lepas = refresh; tarik dan tahan 3,2 detik (dihitung sejak ditahan) = ganti Demo/Live. Indikator bulat dengan ring titik, haptic, dan ripple.
- Pair picker bergaya exchange: kategori di atas, ikon koin (CoinGecko), perubahan 24j, bar volume, favorit, pencarian. Data pair dari exchange terpilih atau CoinGecko; kategori tematik dari CoinGecko.
- Chart (Live, Demo, Pasar): sumber exchange/CoinGecko, interval berkategori, candle/garis, MA, sentuh untuk OHLC, garis Entry/SL/TP dari call terbaru dan posisi aktif.
- Intro: onboarding hanya saat pertama dibuka (sampai "Mulai"); selanjutnya splash logo animasi + font Poppins (OFL) yang hilang halus sekitar 2 detik.
- Toast dan notifikasi foreground disederhanakan.

## v2.4 — ROADMAP dikerjakan
- **Navbar**: floating, rounded, bergaya liquid glass dengan backdrop blur native Android, rim dan kapsul geser. Pada iOS digunakan lapisan kaca translusen.
- **Keamanan (Live)**: kill-switch, mode hanya-baca, batas rugi harian, batas posisi, konfirmasi leverage tinggi, PIN 6 digit (auto-kunci 30 dtk).
- **Trading Live**: daftar order terbuka + batal, ubah leverage, riwayat PnL (Bybit/Bitget/OKX/Binance).
- **Chart**: volume, RSI 14, EMA 50, MA 7/25, zoom & geser, interval 3m/30m/2h/12h, kedalaman order book + trade terbaru, quote WebSocket (Bybit/Binance/OKX mainnet), alert harga langsung dari chart.
- **Demo**: kurva ekuitas, tombol Buy/Sell besar, isi qty dari % saldo, ekspor/impor.
- **Alert harga** + notifikasi sistem saat app di background.
- **UI**: skeleton loading, ikon launcher baru (XO).
- **Teknis**: retry GET dengan backoff (POST/DELETE tidak pernah di-retry), perbaikan bug `isRunning` di Kotlin, tes baru `__tests__/safety.test.ts`.
- **Belum**: i18n Inggris, tablet/landscape, pecah controller.ts, simulasi funding fee, biometrik, WebSocket Bitget/testnet.
- **Belum teruji di perangkat/APK** — endpoint order/leverage ditulis dari dokumentasi; uji di testnet atau akun kecil dulu.

## v2.5 — tampilan, animasi, struktur
- **Animasi**: transisi tab berarah (geser sesuai arah tab, pegas), judul AppBar cross-fade, bottom sheet pegas + **geser ke bawah untuk menutup** (scrim ikut memudar).
- **Layout**: konten dibatasi lebar 720 dan navbar 460 agar rapi di tablet/landscape.
- **WebSocket**: ditambah Bitget (mainnet) dan testnet Bybit/Binance/OKX; titik hijau di chart saat streaming. Reconnect otomatis dengan backoff.
- **Struktur**: `controller.ts` (698 baris) dipecah menjadi `src/ctl/*` (core, exchange, demo, signals, telegram, automation, manage, replay, orders, safety, lifecycle). Perilaku tidak diubah; urutan hook sama.
- Belum: audit bug mendalam, terjemahan Inggris, simulasi funding fee, biometrik. Semua belum diuji di perangkat.

## v2.5.1 — Hyperlink

- Nama yang tampil di aplikasi, intro, launcher, notifikasi, dan pengaturan sistem menjadi **Hyperlink**. Logo dan ikon yang sudah ada dipertahankan; ID aplikasi Android lama tidak diubah agar update tetap kompatibel.
- Minimum Android API **31 (Android 12)**, compile API 36 dan target API 36. Navbar menggunakan ViewManager Kotlin tanpa library tambahan dan RenderEffect native atas snapshot konten di belakangnya. Blur Android dapat dipakai ulang lewat komponen `NativeBackdropBlurView`; iOS memakai fallback translucent, bukan blur native.
- Settings dibagi menjadi sembilan kategori dan dipilih melalui popup beranimasi. Aksi Exchange dan Telegram yang padat digabungkan dalam popup tindakan kontekstual; label navbar dipisahkan dari animasi pill agar tidak saling bertumpuk.
- Gestur tarik-tahan untuk berpindah Live/Demo ditetapkan ke **3200 ms**. Versi aplikasi 2.5.1 (versionCode 26).


## v2.5.2 — UI & Android arm64
- Bottom navbar dipendekkan menjadi 66 dp, dengan latar kaca translusen yang cukup pekat, tanpa blur; indikator tab memakai pegas ringan. App bar atas diringkas sedikit.
- Semua slider kini memakai track/knob membulat, animasi perubahan nilai dan posisi gesture berbasis delta agar tidak meloncat. Pengaturan margin, confidence, dan batas akun Live dibuka lewat panel pop-up, juga tersedia langsung dari kartu Beranda.
- Indikator tarik Live/Demo dibuat pill ringkas agar tidak menimpa kartu; target mode dikunci sejak gesture dimulai. Ambang tahan tetap **3.200 ms**.
- Dua tema baru: **Midnight Exchange** (biru-navy/cyan) dan **Emerald Wallet** (hijau/emerald), masing-masing memiliki palet terang dan gelap. Inspirasi hanya mengambil prinsip umum kontras, hierarki saldo, navigasi ringkas, serta aksen warna dari [panduan UI aplikasi kripto Tino Design](https://tino.design/blog/cryptocurrency-mobile-application-ux-and-ui-examples-and-ideas-for-inspiration); tidak memakai aset atau logo merek lain.
- Logo yang dikirim dipotong menjadi mark di tengah, dirender monokrom, dan dipasang ke ikon launcher Android serta splash.
- Efek suara antarmuka memakai sampel OGG Kenney berlisensi CC0; pengaturan menyediakan on/off, tiga template (Lembut, Crisp, Wallet), volume, dan tombol pratinjau. Detail sumber dan kredit ada di [`SOUND_ASSETS.md`](SOUND_ASSETS.md).
- APK Android dibatasi ke **arm64-v8a**. Minimum API 31, compile/target API 36 tetap dipertahankan. Untuk menghasilkan tepat satu APK Release:

```bash
npm ci
bash scripts/prepare-tdlib.sh
cd android && ./gradlew clean assembleRelease
```

APK berada di `android/app/build/outputs/apk/release/app-release.apk`. Build lokal memakai debug key jika signing key release khusus tidak disediakan; siapkan signing key sendiri untuk distribusi publik.
- Versi Android: **versionName 2.5.2**, **versionCode 27**.
- Dependensi template `@react-native/new-app-screen` yang tak pernah dipakai dihapus. Modul blur native dan komponen JS khususnya juga dilepas karena navbar kini tanpa blur; dependensi aplikasi lain dipertahankan.
- Catatan v2.5.1 di atas bersifat historis; bundle ini adalah versi terkini tanpa efek blur.

## v2.5.3 — stabilitas & penyegaran UI
- Memperbaiki crash slider dengan satu driver native untuk progress/knob, serta uji rentang drag berulang dan overshoot.
- Navbar translusen kini mengambil warna dari palet tema yang aktif; ditambahkan **Copper Studio** (terang/gelap) tanpa mengganti tema v2.5.2 yang sudah ada.
- Pull-to-refresh dan tahan **3,2 detik** untuk Live/Demo tersedia di semua tab; tab yang sedang dibuka tidak berubah ketika mode akun berganti.
- TDLib mulai segera setelah kredensial lokal tersedia; progress bar app bar ikut menandai proses startup dan hilang setelah selesai.
- Beranda kini menampilkan dashboard → Call terbaru → chart call terbaru. Sumber harga Demo dipindah ke akhir panel.
- Pasar membatasi render awal ke 20 aset dengan tombol tambah, untuk meringankan perpindahan pertama.
- Intro splash minimal **3 detik**, termasuk auto-close onboarding awal; mark logo monochrome diperbesar. Indikator tarik dan titik ring diperbesar. Ditambahkan template suara **Deep 70–140 Hz** (8 nada sintetis lokal); template CC0 lama tetap tersedia.
- Android tetap **arm64-v8a only**, minimum API **31**, versionName **2.5.3**, versionCode **28**.

### Pembaruan source untuk handoff Release
- Order manual Demo (market/limit) dipindah ke Pasar; order Live manual market memakai daftar pair aktif dan aturan instrumen exchange yang dipilih, wajib Stop Loss, serta konfirmasi terpisah sebelum pengiriman. Tidak ada transaksi real yang dijalankan selama pengujian source.
- Auto-entry Live opsional dan default mati; hanya call Telegram baru yang tervalidasi dapat memicunya. Harga/entry band, akun/posisi terbaru, kill-switch, mode baca-saja, batas posisi/rugi, dan konfirmasi risiko tetap diperiksa; kasus yang butuh konfirmasi tambahan ditahan untuk review.
- Pemilih pair order bersumber dari seluruh ticker kontrak perpetual USDT aktif exchange, sementara min qty/step/notional/leverage diambil per pair dari metadata exchange. Chart pada Beranda, Demo, dan detail Pasar dapat diminimalkan; kurva ekuitas dihapus.
- PIN mendapat keypad/layar beranimasi dan autentikasi biometrik Android lewat `react-native-keychain` yang sudah menjadi dependensi, dengan PIN tetap sebagai fallback. Intro memakai ulang mark Hyperlink yang dirapikan, tanpa mengambil logo/aset merek lain.
- Template suara baru: Piano, Harp, Violin, Cello, dan Acoustic Guitar dengan nada acak per pemutaran; atribusi dan lisensi sampel/asset tercatat di [`SOUND_ASSETS.md`](SOUND_ASSETS.md).

## v2.5.4 — PIN, order manual, suara & notifikasi
- PIN benar merapat ke tengah dengan fade sinkron tanpa rotasi; PIN salah mengembang keluar kembali ke enam posisi awal. Setelah PIN diterima, shell beranda muncul dengan transisi lembut. Akses biometrik menjadi ikon fingerprint di kiri angka 0.
- Order manual memiliki slider leverage sesuai batas pair dan slider alokasi margin 1–20% dengan preset; Qty tetap dapat diubah langsung. Order Live tetap market-only dan menunggu konfirmasi final.
- Efek WND11 dan instrumen dirutekan ke volume media utama Android. Notifikasi sistem lokal meminta izin Android, mencakup hasil order serta event signal/alert yang benar-benar terpantau, dan tidak menjanjikan push setelah app dihentikan.
- Setelan menyediakan Keluar dari aplikasi: monitoring latar dihentikan dan task ditutup. Android tidak mengizinkan app melakukan force-stop terhadap prosesnya sendiri.
- Android tetap **arm64-v8a only**, minimum API **31**, versionName **2.5.4**, versionCode **29**.

Build Android Release tepat satu kali (arsip ini disiapkan untuk Ruby; proses build tidak dijalankan dari sesi ini):

```bash
npm ci
bash scripts/prepare-tdlib.sh
cd android && ./gradlew assembleRelease
```

## v2.6
- **Dial analog** (`src/Dial.tsx`) menggantikan slider di Order Manual: cincin titik seperti indikator tarik-refresh, knob yang diputar, tombol − / +, preset cepat.
- **Order Manual ala exchange**: Buy/Sell, Cross/Isolated, Market/Limit, dial Leverage & Margin %, TP/SL dengan pintasan ROI, ringkasan (nilai posisi, margin, fee, likuidasi, R:R), validasi.
  - **Live**: pair, harga (WebSocket), aturan instrumen dari exchange terpilih.
  - **Demo**: pair & harga dari CoinGecko (sumber harga Demo dikunci ke CoinGecko saat kartu dipakai).
- **Chart baru**: timeframe inline, geser (drag), cubit untuk zoom, tahan untuk crosshair, ketuk dua kali reset, layar penuh; indikator MA/EMA/Bollinger/VWAP + panel Volume/RSI/MACD; tipe Candle/Garis/Area; statistik & fundamental CoinGecko.
- **PIN (gaya video OTP)**: 6 tile berjajar dengan caret; setelah lengkap tile meluncur ke lingkaran dan berputar saat verifikasi; benar → hijau, menyatu jadi satu kotak bercahaya + percikan titik; salah → merah, kembali ke baris, bergetar, terhapus.
- Tes baru: dial, orderMath, chartMath.
