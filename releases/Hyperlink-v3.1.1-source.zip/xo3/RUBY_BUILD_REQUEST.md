# Build request for Ruby — Hyperlink 3.1.1

Please build **exactly one Android Release APK** from this source package. Do not build a Debug APK, another ABI, or an additional APK. Do not modify the source unless required to make this one Release build succeed. Return the resulting APK path and build result. Only this new 3.1.1 result should be posted to the Group; do not repost older source or APKs.

## Release configuration

- Application ID / package: `com.tradepilotnative` (preserve it)
- ABI: **arm64-v8a only**
- minSdk: **31**
- targetSdk: **36**
- versionName: **3.1.1**
- versionCode: **35**
- Preserve the existing Live/Demo separation and safety behavior.

The Android Gradle configuration defaults to versionName 3.1.1/versionCode 35. This source preserves the **DeafDeep** sound pack, makes the navbar tint more transparent to reveal its existing native adaptive blur, starts Live and Demo latest-call charts collapsed, and adds blurred/dimmed backdrops to app menus, popovers, sheets, and confirmation dialogs. Manual chart expansion and explicit destructive confirmations remain available. Live/Demo trading, package ID, and safety behavior are unchanged.

The blur dependency is `@react-native-community/blur` **4.4.1**; package docs: [npm](https://www.npmjs.com/package/@react-native-community/blur), exact package tarball: https://registry.npmjs.org/@react-native-community/blur/-/blur-4.4.1.tgz. Android documents a maximum `blurAmount` of 32; the navbar retains 18 and modal backdrops use 14 with a fixed radius/downsample setting. App minimum API 31 avoids the older Android RenderScript path; blur intensity itself is not animated per frame.

## Build exactly once

Run the normal dependency/setup steps, then invoke **one** Gradle Release task only:

```bash
npm ci
bash scripts/prepare-tdlib.sh
cd android && APP_VERSION_NAME=3.1.1 APP_VERSION_CODE=35 ./gradlew assembleRelease
```

Expected output: `android/app/build/outputs/apk/release/app-release.apk`.

No APK or Gradle build was run during source preparation. Unit tests use mocks; do not place a real exchange order during validation. Do not claim push notifications while the app process is terminated. If no release signing key is configured, report that the output uses the existing debug signing configuration.

## Source validation completed

- `npm ci --no-audit`: completed successfully.
- `npm run typecheck`: passed.
- `npm test -- --runInBand`: passed, **17 suites / 78 tests**.
- Targeted ESLint on the four changed TypeScript files: **0 errors**; it reports 182 inline-style warnings across those files.
- Static release checks: DeafDeep assets and native mappings preserved; application ID `com.tradepilotnative`, ABI `arm64-v8a`, minSdk 31, targetSdk 36, versionName 3.1.1, and versionCode 35 are correct.
- No APK or Gradle Release build was run during source preparation, and the new backdrop has not yet been visually verified in a built Android app. Please perform exactly one matching Release build as specified above.
- Library limitation: `@react-native-community/blur` documents Android `blurAmount` up to 32 (higher values clamp); this source uses 18 for the navbar and 14 for modal backdrops. The app's API 31 minimum avoids the legacy pre-31 Android blur path. The underlying Dimezis BlurView cannot blur `SurfaceView`-based content, though the app's ordinary React Native views are supported. No known Release-build blocker was found in the library documentation.
